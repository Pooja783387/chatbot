from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer, util
import pandas as pd
import os
import sys
import uvicorn # Ensure uvicorn is imported

app = FastAPI()

# CORS Settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Determine base path for bundled resources (like models and public) ---
# sys._MEIPASS is the path to the temporary directory where PyInstaller extracts bundled data.
if getattr(sys, 'frozen', False):
    # Running as a bundled executable
    base_dir = sys._MEIPASS
else:
    # Running as a regular Python script (for development)
    # Assumes the script is in 'backend' and 'public' is one level up
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Mount public/ folder for static files (HTML, CSS, JS)
# Use the determined public_path
public_path = os.path.join(base_dir, 'public')
app.mount("/static", StaticFiles(directory=public_path), name="static")

@app.get("/")
def read_index():
    # FileResponse should also point to the correct path within the bundle
    return FileResponse(os.path.join(public_path, "index.html"))

# --- Excel File Path (External) ---
# This assumes Book3.xlsx will be placed in the same directory as the .exe after building.
excel_file_name = "Book3.xlsx"

# Error handling for the Excel file
try:
    df = pd.read_excel(excel_file_name, header=None, names=["Questions", "Answers"])
except FileNotFoundError:
    print(f"Error: {excel_file_name} not found. Please ensure it's in the same directory as the executable.")
    # Create an empty DataFrame so the app can still start, though without data
    df = pd.DataFrame(columns=["Questions", "Answers"])
except Exception as e:
    print(f"An error occurred while loading {excel_file_name}: {e}")
    df = pd.DataFrame(columns=["Questions", "Answers"])

questions = df["Questions"].astype(str).tolist()
answers = df["Answers"].astype(str).tolist()
combined_texts = [f"Q: {q} A: {a}" for q, a in zip(questions, answers)]

# --- Load SentenceTransformer model from bundled path ---
# The model 'all-MiniLM-L6-v2' will be copied into 'models/all-MiniLM-L6-v2' inside the bundle.
# So, we construct the path relative to base_dir (sys._MEIPASS).
model_name_folder = "sentence-transformers_all-MiniLM-L6-v2" # This is the actual folder name in .cache
model_local_path = os.path.join(base_dir, "models", model_name_folder)

# Load model outside of request handlers for efficiency
try:
    model = SentenceTransformer(model_local_path)
    combined_embeddings = model.encode(combined_texts, convert_to_tensor=True)
except Exception as e:
    print(f"Error loading SentenceTransformer model from {model_local_path}: {e}")
    print("Please ensure the model folder is correctly bundled or accessible.")
    # Fallback or exit if model loading fails
    # You might want to have a default empty model or gracefully degrade functionality
    model = None # Set to None if loading fails to prevent further errors
    combined_embeddings = None # Set to None if loading fails

greeting_responses = {
    "hi": "Hello! How can I help you today?",
    "hello": "Hi there! Ask me anything.",
    "thanks": "You're welcome!",
    "bye": "Goodbye!",
    "how are you": "I'm a bot, but doing great. You?"
}
greeting_phrases = list(greeting_responses.keys())
# Only encode greetings if model loaded successfully
if model:
    greeting_embeddings = model.encode(greeting_phrases, convert_to_tensor=True)
else:
    greeting_embeddings = None # Handle case where model failed to load

class Query(BaseModel):
    query: str

@app.post("/ask")
def ask_question(data: Query):
    user_input = data.query.strip().lower()

    if not model:
        return {"answer": "Chatbot is currently unavailable: model failed to load."}
    if df.empty and not greeting_responses: # If excel is empty AND no greeting responses
         return {"answer": "Sorry, I am currently unable to provide answers. The data source might be missing or empty."}


    user_embedding = model.encode(user_input, convert_to_tensor=True)

    # Check for greetings
    if greeting_embeddings is not None:
        greet_score = util.cos_sim(user_embedding, greeting_embeddings).max().item()
        if greet_score > 0.3: # Adjust threshold if needed
            idx = util.cos_sim(user_embedding, greeting_embeddings).argmax().item()
            return {"answer": greeting_responses[greeting_phrases[idx]]}

    # Check for answers from Excel, only if data is loaded
    if combined_embeddings is not None and not df.empty:
        scores = util.cos_sim(user_embedding, combined_embeddings)
        max_score = scores.max().item()
        if max_score < 0.4: # You can adjust this threshold
            return {"answer": "Sorry, I couldn't find a relevant answer for that."}
        top_idx = scores.argmax().item()
        return {"answer": answers[top_idx]}
    else:
        return {"answer": "Sorry, I couldn't find a relevant answer for that."}


# --- IMPORTANT: Explicitly start the Uvicorn server ---
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)