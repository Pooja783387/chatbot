
var chatToggle = document.getElementById("chat-toggle");
var chatPopup = document.getElementById("chat-popup");
var closeChat = document.getElementById("close-chat");
var chatBox = document.getElementById("chat-box");
var chatForm = document.getElementById("chat-form");
var userInput = document.getElementById("user-input");


chatToggle.onclick = function () {
  chatPopup.classList.remove("hidden");
};


closeChat.onclick = function () {
  chatPopup.classList.add("hidden");
};


chatForm.onsubmit = function (e) {
  e.preventDefault();
  var message = userInput.value.trim();
  if (!message) return;

  appendMessage("You", message, "user-msg");
  userInput.value = "";

  appendMessage("Bot", "Typing...", "bot-msg", true);


  fetch("/ask", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query: message
    }),
  })
    .then(function (res) {

      if (!res.ok) {

        return res.text().then(function (text) {
          throw new Error('Network response was not ok. Status: ' + res.status + ' - ' + text);
        });
      }
      return res.json();
    })
    .then(function (data) {

      setTimeout(function () {

        if (chatBox.lastChild) {
          chatBox.lastChild.remove();
        }
        appendMessage("Bot", data.answer || "Sorry, I didn't get that.", "bot-msg");
      }, 600);
    })
    .catch(function (error) {

      console.error("Error fetching bot response:", error);
      // Remove "Typing..." message and show an error message
      if (chatBox.lastChild) {
        chatBox.lastChild.remove();
      }
      appendMessage("Bot", "Sorry, something went wrong.", "bot-msg");
    });

};


function appendMessage(sender, message, className, skipScroll) {

  skipScroll = (typeof skipScroll === 'boolean') ? skipScroll : false;

  var div = document.createElement("div");
  div.className = className;
  div.innerHTML = "<strong>" + sender + ":</strong> " + message;
  chatBox.appendChild(div);
  if (!skipScroll) {
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}