const chatToggle = document.getElementById("chat-toggle");
const chatPopup = document.getElementById("chat-popup");
const closeChat = document.getElementById("close-chat");
const chatBox = document.getElementById("chat-box");
const chatForm = document.getElementById("chat-form");
const userInput = document.getElementById("user-input");

chatToggle.onclick = () => {
  chatPopup.classList.remove("hidden");
};

closeChat.onclick = () => {
  chatPopup.classList.add("hidden");
};

chatForm.onsubmit = async (e) => {
  e.preventDefault();
  const message = userInput.value.trim();
  if (!message) return;

  appendMessage("You", message, "user-msg");
  userInput.value = "";

  appendMessage("Bot", "Typing...", "bot-msg", true);

  try {
    const res = await fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: message }),
    });
    const data = await res.json();

    setTimeout(() => {
      chatBox.lastChild.remove(); // remove 'Typing...'
      appendMessage("Bot", data.answer || "Sorry, I didn't get that.", "bot-msg");
    }, 600);
  } catch {
    chatBox.lastChild.remove();
    appendMessage("Bot", "Sorry, something went wrong.", "bot-msg");
  }
};

function appendMessage(sender, message, className, skipScroll = false) {
  const div = document.createElement("div");
  div.className = className;
  div.innerHTML = `<strong>${sender}:</strong> ${message}`;
  chatBox.appendChild(div);
  if (!skipScroll) chatBox.scrollTop = chatBox.scrollHeight;
}
